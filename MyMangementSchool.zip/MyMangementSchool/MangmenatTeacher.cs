﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyMangementSchool
{
    public partial class MangmenatTeacher : Form
    {
        public static string id_emploey;
        public static string name_Teacher;
        public static string Price;

        public MangmenatTeacher()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "" && textBox6.Text == "" && textBox7.Text == "")
            {
                MessageBox.Show("يراج ملئ الحقول");
            }
            else
            {
                if (LoginMangmentTeacher.Rank == "Mangment")
                {
                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        x.Image_Teacher = openFileDialog1.FileName;
                        x.Price = int.Parse(textBox6.Text);
                        x.num_emploey = int.Parse(textBox7.Text);
                        x.name_Teacher = textBox5.Text;
                        x.INSERT_Teacher();
                        dataGridView1.DataSource = x.SELECT_Mangment_Teacher();
                       
                    }
                }
                else
                {
                    MessageBox.Show("انت لست المدير", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
            }
        }

        private void MangmenatTeacher_Load(object sender, EventArgs e)
        {
          textBox7.Text = LoginMangmentTeacher.id_emploey;
          try
          {
              dataGridView1.DataSource = x.SELECT_Mangment_Teacher();
          }
          catch (Exception ex)
          {
              MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
          }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            pictureBox1.ImageLocation = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            id_emploey = textBox7.Text;
            name_Teacher = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            Price = textBox3.Text;
            SalaryTeacher i = new SalaryTeacher();
            i.Show();
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
