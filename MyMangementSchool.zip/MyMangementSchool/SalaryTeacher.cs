﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyMangementSchool
{
    public partial class SalaryTeacher : Form
    {
        public SalaryTeacher()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "")
                {
                    MessageBox.Show("يجب ملئ الحقول");
                }
                else
                {
                    x.name_Teacher = textBox1.Text;
                    x.Price = int.Parse(textBox2.Text);
                    x.num_emploey4 = int.Parse(textBox3.Text);
                    x.INSERT_Salary_Teacher();
                    dataGridView1.DataSource = x.SELECT_Salary_Teacher();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
        }

        private void SalaryTeacher_Load(object sender, EventArgs e)
        {
            if (LoginMangmentTeacher.fast == "on")
            {
                textBox1.Text = MangmenatTeacher.name_Teacher;
                textBox2.Text = MangmenatTeacher.Price;
                textBox3.Text = MangmenatTeacher.id_emploey;
                dataGridView1.DataSource = x.SELECT_Salary_Teacher();
            }
            if (LoginSalaryTeacher.fast == "off")
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = LoginSalaryTeacher.id_emploey;
                dataGridView1.DataSource = x.SELECT_Salary_Teacher();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text == "")
                {
                    dataGridView1.DataSource = x.SELECT_Salary_Teacher();
                }
                else
                {
                    x.data = textBox4.Text;
                    dataGridView1.DataSource = x.serch_Teacher();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
                x.Close();
            }
        }
    }
}
