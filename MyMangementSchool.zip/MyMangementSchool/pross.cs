﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace MyMangementSchool
{
    class pross
    {
        SqlConnection con = new SqlConnection(@"Server=.\SQLEXPRESS;DataBase=school;Integrated Security=True;");
        public string username { get; set; }
        public string password { get; set; }
        //Create  Outaly  INsert
        public string name_Student { get; set; }
        public int Level_Student { get; set; }
        public int Price { get; set; }
        public int num_emploey2 { get; set; }
        public string image_Student { get; set; }
        public SqlDataReader SELECT_username()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Employees WHERE username=@username AND password=@password ", con);
            cmd.Parameters.AddWithValue("@username",username);
            cmd.Parameters.AddWithValue("@password",password);
            return (cmd.ExecuteReader());
        }
        public string Close()
        {
            con.Close();
            return ("");
        }
        public string insert()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Outlay(name_Student,Level_Student,Price,num_emploey2,image_Student)VALUES(@name_Student,@Level_Student,@Price,@num_emploey2,@image_Student)", con);
            cmd.Parameters.AddWithValue("@name_Student", name_Student);
            cmd.Parameters.AddWithValue("@Level_Student", Level_Student);
            cmd.Parameters.AddWithValue("@Price", Price);
            cmd.Parameters.AddWithValue("@num_emploey2", num_emploey2);
            cmd.Parameters.AddWithValue("@image_Student", image_Student);
            cmd.ExecuteNonQuery();
            con.Close();
            return ("Send Secassfuly");
        }
        public object select()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Outlay", con);
            DataSet i = new DataSet();
            reader.Fill(i, "t");
            con.Close();
            return(i.Tables["t"]);
        }
        public string Rank { get; set; }
        public string image_emploey { get; set; }

        public string Insert_emploey()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Employees(username,password,price,Rank,image_emploey)VALUES(@username,@password,@price,@Rank,@image_emploey)", con);
            cmd.Parameters.AddWithValue("@username",username);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@price", Price);
            cmd.Parameters.AddWithValue("@Rank", Rank);
            cmd.Parameters.AddWithValue("@image_emploey", image_emploey);
            cmd.ExecuteNonQuery();
            con.Close();
            return("");
        }
        public object SELECT_Emploey()
        {
            con.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("SELECT * FROM Employees ",con);
            DataSet l = new DataSet();
            cmd.Fill(l,"t");
            con.Close();
            return(l.Tables["t"]);
        }
        public int num_emploey3 { get; set; }
        public string INSERT_Salary_emploey()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Salary_emploey(name_Emploey,Price,Rank,data,num_emploey3)VALUES(@name_Emploey,@Price,@Rank,@data,@num_emploey3)", con);
            cmd.Parameters.AddWithValue("@name_Emploey", username);
            cmd.Parameters.AddWithValue("@Price", Price);
            cmd.Parameters.AddWithValue("@Rank",Rank);
            cmd.Parameters.AddWithValue("@data", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@num_emploey3",num_emploey3);
            cmd.ExecuteNonQuery();
            con.Close();
            return ("");
        }
        public object SELECT_Salary_emploey()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Salary_emploey", con);
            DataSet i = new DataSet();
            reader.Fill(i,"m");
            con.Close();
            return(i.Tables["m"]);
        }
        public string data { get; set; }
        public object serch_salary()
        {
            con.Open();
            SqlDataAdapter serch = new SqlDataAdapter("SELECT * FROM Salary_emploey WHERE data Like @data", con);
            serch.SelectCommand.Parameters.AddWithValue("@data","%"+data+"%");
            DataSet i = new DataSet();
            serch.Fill(i, "t");
            con.Close();
            return(i.Tables["t"]);
        }
        public string name_Teacher { get; set; }
        public int num_emploey4 { get; set; }
        public string INSERT_Salary_Teacher()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Salary_Teacher(name_Teacher,price,num_emploey4,Data)VALUES(@name_Teacher,@price,@num_emploey4,@Data)", con);
            cmd.Parameters.AddWithValue("@name_Teacher",name_Teacher);
            cmd.Parameters.AddWithValue("@price", Price);
            cmd.Parameters.AddWithValue("@num_emploey4",num_emploey4);
            cmd.Parameters.AddWithValue("@Data",DateTime.Now.ToString());
            cmd.ExecuteNonQuery();
            con.Close();
            return ("");
        }
        public object SELECT_Salary_Teacher()
        {
            con.Open();
            SqlDataAdapter select = new SqlDataAdapter("SELECT * FROM Salary_Teacher", con);
            DataSet i = new DataSet();
            select.Fill(i,"t");
            con.Close();
            return(i.Tables["t"]);
        }
        public object serch_Teacher()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Salary_Teacher WHERE Data LIKE @Data", con);
            reader.SelectCommand.Parameters.AddWithValue("@Data","%"+data+"%");
            DataSet i = new DataSet();
            reader.Fill(i, "t");
            con.Close();
            return (i.Tables["t"]);
        }
        public string Image_Teacher { get; set; }
        public int num_emploey { get; set; }
        public string INSERT_Teacher()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Teachers(image_Teacher,price,num_emploey,name_Teacher)VALUES(@image_Teacher,@price,@num_emploey,@name_Teacher)", con);
            cmd.Parameters.AddWithValue("@image_Teacher",Image_Teacher);
            cmd.Parameters.AddWithValue("@price", Price);
            cmd.Parameters.AddWithValue("@num_emploey", num_emploey);
            cmd.Parameters.AddWithValue("@name_Teacher", name_Teacher);
            cmd.ExecuteNonQuery();
            con.Close();
            return ("");
        }
        public object SELECT_Mangment_Teacher()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Teachers",con);
            DataSet i = new DataSet();
            reader.Fill(i,"t");
            con.Close();
            return (i.Tables["t"]);
        }
        public SqlDataReader SELECT_Teacher()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Teachers",con);
            return(cmd.ExecuteReader());
        }
        public int Lavel_Student { get; set; }
        public int num_Teacher { get; set; }
        public string INSERT_Student()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO students(name_Student,Lavel_Student,Image_Student,price,num_emploey1,num_Teacher) VALUES (@name_Student,@Lavel_Student,@Image_Student,@price,@num_emploey1,@num_Teacher);", con);
            cmd.Parameters.AddWithValue("@name_Student",name_Student);
            cmd.Parameters.AddWithValue("@Lavel_Student", Level_Student);
            cmd.Parameters.AddWithValue("@Image_Student", image_Student);
            cmd.Parameters.AddWithValue("@price", Price);
            cmd.Parameters.AddWithValue("@num_emploey1", num_emploey);
            cmd.Parameters.AddWithValue("@num_Teacher", num_Teacher);
            cmd.ExecuteNonQuery();
            con.Close();
            return("");
        }
        public object SELECT_Student()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Students",con);
            DataSet i = new DataSet();
            reader.Fill(i,"t");
            con.Close();
            return(i.Tables["t"]);
        }
        public object Serch_Student_outly()
        {
            con.Open();
            SqlDataAdapter reader = new SqlDataAdapter("SELECT * FROM Outlay WHERE name_Student LIKE @name_Student  AND Data LIKE @Data ",con);
            reader.SelectCommand.Parameters.AddWithValue("@name_Student","%"+name_Student+"%");
            reader.SelectCommand.Parameters.AddWithValue("@Data","%"+data+"%");
            DataSet i = new DataSet();
            reader.Fill(i,"g");
            con.Close();
            return(i.Tables["g"]);
        }
    }
}
