﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyMangementSchool
{
    public partial class MangmentEmploey : Form
    {
        public static string username;
        public static string price;
        public static string Rank;
        public static string id_emploey;
        public static string fast;
        public MangmentEmploey()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void MangmentEmploey_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Mangment");
            comboBox1.Items.Add("Accunting");
            comboBox1.Items.Add("HR");
            comboBox1.Items.Add("Data entry");
            try
            {
                dataGridView1.DataSource = x.SELECT_Emploey();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (LoginMangmentEmploey.Rank == "Accunting")
            {
                MessageBox.Show("انت محاسب من يضف المواظفين هو المدير","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && comboBox1.Text == "")
                    {
                        MessageBox.Show("يجب ملئ الحقول", "خطاء", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (openFileDialog1.ShowDialog() == DialogResult.OK)
                        {
                            x.username = textBox1.Text;
                            x.password = textBox2.Text;
                            x.Price = int.Parse(textBox3.Text);
                            x.Rank = comboBox1.Text;
                            x.image_emploey = openFileDialog1.FileName;
                            x.Insert_emploey();
                            dataGridView1.DataSource = x.SELECT_Emploey();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox5.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox6.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox7.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox8.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox9.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            pictureBox1.ImageLocation = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            username = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            price = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            Rank = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            id_emploey = LoginMangmentEmploey.id_emploey;
            fast = "t";
            SalaryEmploey i = new SalaryEmploey();
            i.Show();
        }
    }
}
