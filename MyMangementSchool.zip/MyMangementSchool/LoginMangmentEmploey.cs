﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class LoginMangmentEmploey : Form
    {
        public static string id_emploey;
        public static string Rank;
        public LoginMangmentEmploey()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                x.username = textBox1.Text;
                x.password = textBox2.Text;
                SqlDataReader reader = x.SELECT_username();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                      if (reader["Rank"].ToString() == "Mangment")
                      {
                          id_emploey = reader["id_emploey"].ToString();
                          Rank = reader["Rank"].ToString();
                          MangmentEmploey o = new MangmentEmploey();
                          o.Show();
                          this.Hide();
                      }
                      else if (reader["Rank"].ToString() == "Accunting")
                      {
                          id_emploey = reader["id_emploey"].ToString();
                          Rank = reader["Rank"].ToString();
                          MangmentEmploey o = new MangmentEmploey();
                          o.Show();
                          this.Hide();
                      }
                      else
                      {
                          label3.Text = "أنت لست مدير ";
                      }
                    }
                    x.Close();
                }
                else
                {
                    label3.Text = "انت لست المدير";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                label3.Text = ex.Message.ToString();
                x.Close();
            }
        }
    }
}
