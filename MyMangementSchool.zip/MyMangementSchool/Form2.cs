﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class Form2 : Form
    {
        public static string id_emploey;
        public Form2()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            LoginSalaryTeacher x = new LoginSalaryTeacher();
            x.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pross m = new pross();
            textBox4.Text = Form1.Id_emploey.ToString();
            label4.Text = DateTime.Now.Day.ToString();
            label5.Text = DateTime.Now.Month.ToString();
            timer1.Enabled = true;
            textBox1.Text = MangmentStudent.name_Student;
            textBox2.Text = MangmentStudent.Level_Student;
            textBox3.Text = MangmentStudent.Price;
            dataGridView1.DataSource = m.select();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToLongTimeString();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            pross x = new pross();
            openFileDialog2.Title = "أختار صورة للطالب";
            openFileDialog2.Filter = "jpg |*.jpg|png|*.png|bmp|*.bmp";
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    x.name_Student = textBox1.Text;
                    x.Level_Student =int.Parse(textBox2.Text);
                    x.Price = int.Parse(textBox3.Text);
                    x.num_emploey2 = int.Parse(textBox4.Text);
                    x.image_Student = openFileDialog2.FileName;
                    x.insert();
                    dataGridView1.DataSource = x.select();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel ,MessageBoxIcon.Error);
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Music Video MP4|*.mp4|Music Video MP3|*.mp3";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = openFileDialog1.FileName;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                pictureBox1.ImageLocation = dataGridView1.CurrentRow.Cells[5].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erorr", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoginMangmentEmploey x = new LoginMangmentEmploey();
            x.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginSalaryEmploey p = new loginSalaryEmploey();
            p.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoginMangmentTeacher i = new LoginMangmentTeacher();
            i.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            id_emploey = textBox4.Text;
            MangmentStudent x = new MangmentStudent();
            x.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MangmentPrice l = new MangmentPrice();
            l.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MyProgram o = new MyProgram();
            o.Show();
        }
    }
}
