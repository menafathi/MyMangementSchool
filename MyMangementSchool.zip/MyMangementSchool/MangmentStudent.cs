﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MyMangementSchool
{
    public partial class MangmentStudent : Form
    {
        public static string name_Student;
        public static string Level_Student;
        public static string Price;
        public MangmentStudent()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void MangmentStudent_Load(object sender, EventArgs e)
        {
            textBox10.Text = Form1.Id_emploey;
            SqlDataReader reader = x.SELECT_Teacher();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["id_Teacher"].ToString());
            }
            x.Close();
            dataGridView1.DataSource = x.SELECT_Student();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox7.Text == "" && textBox8.Text == "" && textBox9.Text == "" && textBox10.Text == "" && comboBox1.Text == "")
                {
                    MessageBox.Show("يجب ملئ الحقول", "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
                else
                {
                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        x.name_Student = textBox7.Text;
                        x.Level_Student = int.Parse(textBox8.Text);
                        x.image_Student = openFileDialog1.FileName;
                        x.Price = int.Parse(textBox9.Text);
                        x.num_emploey = int.Parse(textBox10.Text);
                        x.num_Teacher = Convert.ToInt32(comboBox1.Text);
                        x.INSERT_Student();
                        dataGridView1.DataSource = x.SELECT_Student();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                x.Close();
            }
           
        }
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            pictureBox1.ImageLocation = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBox6.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            name_Student = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            Level_Student = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            Price = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            Form2 i = new Form2();
            i.Show();
        }
    }
}
