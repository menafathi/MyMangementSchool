﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class MangmentPrice : Form
    {
        public MangmentPrice()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MangmentPrice_Load(object sender, EventArgs e)
        {
            textBox4.Text = Form1.Id_emploey;
            dataGridView1.DataSource = x.select();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    x.name_Student = textBox1.Text;
                    x.Level_Student = Convert.ToInt32(textBox2.Text);
                    x.Price = int.Parse(textBox3.Text);
                    x.num_emploey2 = int.Parse(textBox4.Text);
                    x.image_Student = openFileDialog1.FileName;
                    x.insert();
                    dataGridView1.DataSource = x.select();
                }
        
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox5.Text == "" && textBox6.Text == "")
                {
                    dataGridView1.DataSource = x.select();
                }
                else
                {
                    x.name_Student = textBox6.Text;
                    x.data = textBox5.Text;
                    dataGridView1.DataSource = x.Serch_Student_outly();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }
    }
}
