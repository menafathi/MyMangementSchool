﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class loginSalaryEmploey : Form
    {
        public static string id_emploey;
        public static string fast;
        public loginSalaryEmploey()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {
                    label4.Text = "حقول فارغة يرجي ملئ الحقول";
                }
                else
                {
                    x.username = textBox1.Text;
                    x.password = textBox2.Text;
                    SqlDataReader reader = x.SELECT_username();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (reader["Rank"].ToString() == "Accunting")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "i";
                                SalaryEmploey o = new SalaryEmploey();
                                o.Show();
                                this.Hide();
                            }
                            else if (reader["Rank"].ToString() == "Mangment")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "i";
                                SalaryEmploey o = new SalaryEmploey();
                                o.Show();
                                this.Hide();
                            }
                            else
                            {
                                label4.Text = "لست محاسب او مدير";
                                pross o = new pross();
                                o.Close();
                            }
                        }
                        pross t = new pross();
                        t.Close();
                    }
                    else
                    {
                        label4.Text = "لست مواظف في المدرسة";
                        pross o = new pross();
                        o.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                x.Close();
            }
        }
    }
}
