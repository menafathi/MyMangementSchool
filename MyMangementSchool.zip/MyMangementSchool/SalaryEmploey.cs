﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class SalaryEmploey : Form
    {
       
        public SalaryEmploey()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void SalaryEmploey_Load(object sender, EventArgs e)
        {
            if (MangmentEmploey.fast == "t")
            {
                textBox1.Text = MangmentEmploey.username;
                textBox2.Text = MangmentEmploey.price;
                comboBox1.Text = MangmentEmploey.Rank;
                textBox3.Text = MangmentEmploey.id_emploey;
                try
                {
                    dataGridView1.DataSource = x.SELECT_Salary_emploey();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
            }
            if(loginSalaryEmploey.fast == "i")
            {
                textBox3.Text = loginSalaryEmploey.id_emploey;
                comboBox1.Items.Add("Mangment");
                comboBox1.Items.Add("Accunting");
                comboBox1.Items.Add("HR");
                comboBox1.Items.Add("Data entry");
                try
                {
                    dataGridView1.DataSource = x.SELECT_Salary_emploey();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
            }
            else
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && comboBox1.Text == "")
                {
                    MessageBox.Show("يجب ملئ الحقول", "خطاء", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                }
                else
                {
                    x.username = textBox1.Text;
                    x.Price = int.Parse(textBox2.Text);
                    x.Rank = comboBox1.Text;
                    x.num_emploey3 = int.Parse(textBox3.Text);
                    x.INSERT_Salary_emploey();
                    dataGridView1.DataSource = x.SELECT_Salary_emploey();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                x.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox6.Text == "")
                {
                    dataGridView1.DataSource = x.SELECT_Salary_emploey();
                }
                else
                {
                    x.data = textBox6.Text;
                    dataGridView1.DataSource = x.serch_salary();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
        }
    }
}
