﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MyMangementSchool
{
    public partial class Form1 : Form
    {
        public static string  Id_emploey;
        public Form1()
        {
            InitializeComponent();
        }
        pross o = new pross();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                o.username = textBox1.Text;
                o.password = textBox2.Text;
                SqlDataReader cmd = o.SELECT_username();
                if (cmd.HasRows)
                {
                    while (cmd.Read())
                    {
                    string id = cmd["id_emploey"].ToString();
                    Id_emploey = id.ToString();
                    }
                    Form2 ee = new Form2();
                    ee.Show();
                    this.Hide();
                }
                else
                {
                    label4.Text = "فشل في تسجل ";
                    o.Close();
                }
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                o.Close();
            }
        }
    }
}
