﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    public partial class LoginMangmentTeacher : Form
    {
        public static string id_emploey;
        public static string Rank;
        public static string fast;
        public LoginMangmentTeacher()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {
                    label4.Text = "يجب ملئ الحقول";
                }
                else
                {
                    x.username = textBox1.Text;
                    x.password = textBox2.Text;
                    SqlDataReader reader = x.SELECT_username();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (reader["Rank"].ToString() == "Mangment")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "on";
                                Rank = reader["Rank"].ToString();
                                MangmenatTeacher i = new MangmenatTeacher();
                                i.Show();
                                this.Hide();
                            }
                            else if (reader["Rank"].ToString() == "Accunting")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "on";
                                Rank = reader["Rank"].ToString();
                                MangmenatTeacher i = new MangmenatTeacher();
                                i.Show();
                                this.Hide();
                            }
                            else
                            {
                                label4.Text = "انت لاست المحاسب او المدير";
                            }
                        }
                    }
                    else
                    {
                        label4.Text = "ليوجد احد بذاللك لاسم";
                        x.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OKCancel,MessageBoxIcon.Error);
                x.Close();
            }
        }
    }
}
