﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace MyMangementSchool
{
    
    public partial class LoginSalaryTeacher : Form
    {
        public static string id_emploey;
        public static string fast;
        public LoginSalaryTeacher()
        {
            InitializeComponent();
        }
        pross x = new pross();
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {
                    label4.Text = "يجب ملئ الحقول";
                }
                else
                {
                    x.username = textBox1.Text;
                    x.password = textBox2.Text;
                    SqlDataReader reader = x.SELECT_username();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (reader["Rank"].ToString() == "Accunting")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "off";
                                SalaryTeacher t = new SalaryTeacher();
                                t.Show();
                                this.Hide();
                            }
                            else if(reader["Rank"].ToString() == "Mangment")
                            {
                                id_emploey = reader["id_emploey"].ToString();
                                fast = "off";
                                SalaryTeacher t = new SalaryTeacher();
                                t.Show();
                                this.Hide();
                            }
                            else
                            {
                                label4.Text = "لست مدير او محاسب";
                            }
                        }
                        x.Close();
                    }
                    else
                    {
                        label4.Text = "لايوجد مستخدم بذلك لاسم";
                        x.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                x.Close();
            }
        }
    }
}
